<?php

declare(strict_types=1);

use OCP\Util;

Util::addScript(OCA\Permalink\AppInfo\Application::APP_ID, 'main');

?>

<div id="permalink"></div>
