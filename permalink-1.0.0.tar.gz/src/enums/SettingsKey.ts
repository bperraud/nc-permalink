export enum SettingsKey {
	JwtSecretKey = 'jwt_secret_key',
	PermalinkApiEndpoint = 'permalink_api_endpoint'
}
