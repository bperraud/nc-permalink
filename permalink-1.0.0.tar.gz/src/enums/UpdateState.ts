export enum UpdateState {
	Idle,
	Updating,
	Completed,
	Error,
}
