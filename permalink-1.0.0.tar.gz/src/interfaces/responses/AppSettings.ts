export interface AppSettings {
    jwtSecretKey: string
    permalinkApiEndpoint: string
}
